Zapgun's Creature Set Changes (Version 01)

IMPORTANT NOTICE

I REALLY REALLY REALLY suggest you read this entire thing. This mod requires a few tweaks on your part, or it might not work for you!

WARNING

I've included some of the bosses in these sets. Be warned, if you place one, it can't currently be deleted from the map!

INTRODUCTION

Overall, these creature set changes are meant to allow more flexibility in storytelling while still retaining the ability to quickly generate dungeons by using the auto-spawn "dice" feature. Most of the campaign-specific mobs in these sets have been disabled from the vanilla auto-spawns, although you will still be able to place them by hand. 

Where necessary, I've also included a few new creatures that add missing classes and make the set more AI-friendly. These are designed to still remain as story-neutral as possible (although possibly not canon dnd *gasp*). Some of these are based off existing creatures you've seen, while some are creatures that were disabled in the game for various reasons (probably bugs). I've enabled them and did a little testing to see if they work - but please report any bugs you may find.

INSTALLATION

To install these new creature sets, follow the existing guide on the SCL wiki on how to add mods. Remember that you can only have one active mod at a time, so if this mod interferes with another mod, you will need to find a way to merge the files (an exercise outside of the scope of this document).

The quick instructions are: copy the 'GameConfig.json' file to your Sword Coast Legends directory, and the 'Zapgun'  folder to your Mods directory.

CUSTOM REQUIREMENTS

For some of these creature sets, you should not use the existing defaults, but instead set up a custom creature set based on them, and then add a few customizations to it. For example, for the Skeletal Mage in the new Undead set, you will need to create a custom undead set, and change the second skeleton included to add your own spells, perhaps a slight color change, and then make sure its named 'Skeletal Mage'. This is necessary for a few reasons: 1) I don't currently have access to the language file necessary to create custom names, 2) For some reason creating new default spell action sets doesn't work right, but manually adding them does (maybe a dev can explain to me why!?). 3) I can't adjust any of the colors for these creatures, so it needs to be done in a custom set.

Undead Set

I've changed the overall flavor of this set to be more open ended and flexible for storytelling. 

 - NEW MODEL: Added Angry Spirits to the undead set (these will auto spawn if you are using that feature, and run up to the character to explode with necrotic energy).
 - Ogre Zombies will no longer auto spawn in your dungeons (if you want them they must be hand placed). Who would bury an ogre in a civilized cemetery?!
 - NEEDS CUSTOM: (Second skeleton in the set - the one with witchbolt). Added Skeletal Mages to the undead set (these replace the human cultist caster in auto spawns, although you may still place these by hand). Suggest you add a slight color variation, a few magic spells, and a rename this one to 'Skeletal Mage'.
 - NEEDS CUSTOM: (Third skeleton with eldritch blast) Added Skeletal Defilers to the undead set (these replace the human cultist healers in auto spawns, although you may still place these by hand).  Suggest you add a slight color variation, a few clerical spells (the cultist and undead power sets have some nice evil clerical spells), and a rename this one to 'Skeletal Defiler'.
 - NEW MODEL: Added Flaming Skeletons to the undead set (these will auto spawn, fight and blow up with fire damage).
 - NEEDS CUSTOM: (Second ghoul in the set) Added Ghasts to the creature set, these are tougher ghouls! Suggest you give it a slight color change, and some new evil powers with a rename to 'Ghast' :)
 - Disabled the auto-spawn nature of the Cultist Mage - these now must be hand placed.
 - Disabled the auto-spawn nature of the Cultist Healer - these now must be hand placed.
 - Added a sword wielding Cultist Fanatic to the set - these must be hand placed. (I also recommend you change the color of his clothes in your custom set to make him look a little different)
 - Removed the vampire thrall from auto-spawns, although he can still be hand-placed. (I didn't like the look of his hair!).
 - Changed the vampire boss to a 'miniboss' instead of never spawning. This *technically* should mean he spawns occasionally (I think!)
 - Added the Necromancer's Ghost Boss to this set (placeable only)

Demons & Cultists Set
 - NEEDS CUSTOM: (According to the lore, these have a reddish color). Added Abyssal Ghouls to the set, these will auto-spawn (let me know if you hate this option).
 - NEEDS CUSTOM: (According to the lore, these have a reddish color). Added Abyssal Myrmidon Ghouls to the set, these will auto-spawn (again, let me know if you dislike them in auto-spawn).
 - Added the Shadow Demon boss to this set (placeable only).
 
Underdark Set
 - The beholder boss has been added to this set but will need to be hand placed. (Note: he should only be available for those people who have the deluxe addition of the game).

Spiders
 - Added the demonweb terror boss to this set (placeable only)
 
Gilded Eye
 - Added the mercenary leader boss to this set (placeable only). NOTE: He probably needs to be renamed in a custom character or set to make sense. 
 
 ------
 
EXPERIMENTAL SECTION

These are sets that I haven't had a lot of experience yet with, or that need some extra tweaking before they are ideal. For example, many of the weapons on these sets should not be changed, because you might not be able to give them another weapon afterwards, or they also might be missing mini portraits in the DM editor, etc.

Pirates! 

 - I've included a very nice looking pirate set that was in the data files but not enabled. These look fun and my initial testing seems ok with a few caveats:
	- Not sure if the cutthroat ever comes out of hiding, he may need to be disabled - please let me know.
	- Some of the portraits in the DM menus are missing for these. (when I get time I'll add some)
	- The set shows up as DNF:pirateset1, this is because I haven't added a human-readable value for it into the language files (which currently don't work with normal modding). It won't affect the use of the set. Hopefully this will be fixed once we can add language files without injecting them into the game the hard way.
	
Luskan Guards
 - Your standard thuggy street guards. Although they say 'Luskan' before their names, it shouldn't be hard to adjust them for any city.
 - Bugs:
	- I'm kinda 'meh' on the random weapons, if you use them as a template for a custom creature set them you can choose better looking gear for them.
	- Not really tested these guys - let me know if they don't work.

Mercenaries
 - I've expanded out the set to include a lot of the variety included in the game that wasn't in the base set. Probably these were turned off because they weren't tested! Caviat Emptor!
 
Assassins
 - I've enabled a number of gilded eye assassins in their own set. You will probably need to rename them in a custom set unless you are fighting the gilded eye.
 - The master assassin boss has been added to this set (placeable only).
 
Extras
 - I've included a few "interesting" monsters I found in the data, but these are largely untested. Still, they might be useful as NPCs or the like (some of them don't have combat animation, so be sure and test them first - report any that don't and I'll make a new 'NonCombat' set in the future to split these out). NOTES: these will largely not auto-spawn and will need to be placed by hand.
 - NOTE: A certain monster in this group will vomit up purple goo when you summon him - you may want to place him before your players arrive!

 ------
 
 FUTURE ENDEAVORS & THOUGHTS
 
 Underdark Set
  - Ug. What to do with this? Ideally we need more underdark specific monsters to make this a viable auto-spawning set that doesn't have umberhulks fighting alongside duergar and their friendly drow buddies (gah!). I want to make a better version of this so if anyone has suggestions on how to turn this set into a 'wild underdark frontiers' set, let me know!
  
  Beast Set
  - I wish there was a 'affinity' attribute for these sorts of mixed sets that would force creatures of similar a affinity to spawn together (excluding the rest of the set). For example, all wolves have a 'wolf' affinity, and when one gets selected for auto-spawn, it will only choose other wolves to spwan with at that spot. This would be better then having them all mixed together. Bears fighting with wolves, spiders, and rats is kinda.. wrong.
  
 Bosses
  - There are a few more in the data files, but please let me know if you have requests. I'll also be looking at making them deleteable when I get a chance.
